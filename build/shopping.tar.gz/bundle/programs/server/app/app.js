var require = meteorInstall({"imports":{"api":{"items.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/items.js                                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  Items: () => Items
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Packagings;
module.link("./packagings", {
  Packagings(v) {
    Packagings = v;
  }

}, 1);
const Items = new Mongo.Collection('items');

if (Meteor.isServer) {
  Meteor.publish('items', function itemsPublication() {
    return Items.find({});
  });
}

Items.helpers({
  packaging() {
    return Packagings.findOne({
      _id: this.packagingId
    });
  }

});
Meteor.methods({
  'items.insert'(_ref) {
    let {
      item
    } = _ref;
    const existingItem = Items.findOne({
      packagingId: item.packagingId,
      userId: item.userId,
      retrieved: false,
      payed: false
    });

    if (existingItem) {
      Items.update(existingItem, _objectSpread({}, existingItem, {
        amount: existingItem.amount + item.amount
      }));
    } else {
      Items.insert(_objectSpread({}, item, {
        retrieved: false,
        payed: false
      }));
    }
  }

});
///////////////////////////////////////////////////////////////////////

},"packagings.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/packagings.js                                         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
  Packagings: () => Packagings
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Items;
module.link("./items", {
  Items(v) {
    Items = v;
  }

}, 1);
let Products;
module.link("./products", {
  Products(v) {
    Products = v;
  }

}, 2);
const Packagings = new Mongo.Collection('packagings');

if (Meteor.isServer) {
  Meteor.publish('packagings', function packagingsPublication() {
    return Packagings.find({});
  });
}

Packagings.helpers({
  product() {
    return Products.findOne({
      _id: this.productId
    });
  },

  toRetrieve() {
    let sum = 0;
    Items.find({
      packagingId: this._id,
      retrieved: false
    }).fetch().forEach(item => {
      sum += parseFloat(item.amount);
    });
    return sum;
  },

  retrieved() {
    let sum = 0;
    Items.find({
      packagingId: this._id,
      retrieved: true,
      payed: false
    }).fetch().forEach(item => {
      sum += parseFloat(item.amount);
    });
    return sum;
  }

});
Meteor.methods({
  'packagings.retrieve'(_ref) {
    let {
      packaging,
      retrieved
    } = _ref;
    Items.find({
      packagingId: packaging._id,
      retrieved: !retrieved,
      payed: false
    }).fetch().forEach(item => {
      const existing = Items.findOne({
        userId: item.userId,
        packagingId: item.packagingId,
        retrieved: retrieved,
        payed: false
      });
      let newAmount = item.amount;

      if (existing) {
        newAmount += existing.amount;
        Items.remove(item);
        item = existing;
      }

      Items.update(item, {
        $set: {
          amount: newAmount,
          retrieved: retrieved
        }
      });
    });
  },

  'packagings.setPayed'(_ref2) {
    let {
      packaging
    } = _ref2;
    Items.update({
      packagingId: packaging._id,
      retrieved: true
    }, {
      $set: {
        payed: true
      }
    }, {
      multi: true
    });
  }

});
///////////////////////////////////////////////////////////////////////

},"products.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/products.js                                           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
  Products: () => Products
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Packagings;
module.link("./packagings", {
  Packagings(v) {
    Packagings = v;
  }

}, 1);
const Products = new Mongo.Collection('products');

if (Meteor.isServer) {
  Meteor.publish('products', function productsPublication() {
    return Products.find({});
  });
}

Products.helpers({
  packagings() {
    return Packagings.find({
      productId: this._id
    }).fetch();
  }

});
///////////////////////////////////////////////////////////////////////

},"users.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/users.js                                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
  Users: () => Users
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Items;
module.link("./items", {
  Items(v) {
    Items = v;
  }

}, 1);
const Users = new Mongo.Collection('users');

if (Meteor.isServer) {
  Meteor.publish('users', function usersPublication() {
    return Users.find({});
  });
}

Users.helpers({
  retrieved() {
    return Items.find({
      userId: this._id,
      retrieved: true,
      payed: false
    }).fetch();
  }

});
///////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Users;
module.link("../imports/api/users", {
  Users(v) {
    Users = v;
  }

}, 1);
let Items;
module.link("../imports/api/items", {
  Items(v) {
    Items = v;
  }

}, 2);
let Products;
module.link("../imports/api/products", {
  Products(v) {
    Products = v;
  }

}, 3);
let Packagings;
module.link("../imports/api/packagings", {
  Packagings(v) {
    Packagings = v;
  }

}, 4);
Meteor.startup(() => {});
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3BhY2thZ2luZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Byb2R1Y3RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS91c2Vycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiX29iamVjdFNwcmVhZCIsIm1vZHVsZSIsImxpbmsiLCJkZWZhdWx0IiwidiIsImV4cG9ydCIsIkl0ZW1zIiwiTW9uZ28iLCJQYWNrYWdpbmdzIiwiQ29sbGVjdGlvbiIsIk1ldGVvciIsImlzU2VydmVyIiwicHVibGlzaCIsIml0ZW1zUHVibGljYXRpb24iLCJmaW5kIiwiaGVscGVycyIsInBhY2thZ2luZyIsImZpbmRPbmUiLCJfaWQiLCJwYWNrYWdpbmdJZCIsIm1ldGhvZHMiLCJpdGVtIiwiZXhpc3RpbmdJdGVtIiwidXNlcklkIiwicmV0cmlldmVkIiwicGF5ZWQiLCJ1cGRhdGUiLCJhbW91bnQiLCJpbnNlcnQiLCJQcm9kdWN0cyIsInBhY2thZ2luZ3NQdWJsaWNhdGlvbiIsInByb2R1Y3QiLCJwcm9kdWN0SWQiLCJ0b1JldHJpZXZlIiwic3VtIiwiZmV0Y2giLCJmb3JFYWNoIiwicGFyc2VGbG9hdCIsImV4aXN0aW5nIiwibmV3QW1vdW50IiwicmVtb3ZlIiwiJHNldCIsIm11bHRpIiwicHJvZHVjdHNQdWJsaWNhdGlvbiIsInBhY2thZ2luZ3MiLCJVc2VycyIsInVzZXJzUHVibGljYXRpb24iLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLGFBQUo7O0FBQWtCQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSixpQkFBYSxHQUFDSSxDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUFsQkgsTUFBTSxDQUFDSSxNQUFQLENBQWM7QUFBQ0MsT0FBSyxFQUFDLE1BQUlBO0FBQVgsQ0FBZDtBQUFpQyxJQUFJQyxLQUFKO0FBQVVOLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0ssT0FBSyxDQUFDSCxDQUFELEVBQUc7QUFBQ0csU0FBSyxHQUFDSCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlJLFVBQUo7QUFBZVAsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTSxZQUFVLENBQUNKLENBQUQsRUFBRztBQUFDSSxjQUFVLEdBQUNKLENBQVg7QUFBYTs7QUFBNUIsQ0FBM0IsRUFBeUQsQ0FBekQ7QUFJckcsTUFBTUUsS0FBSyxHQUFHLElBQUlDLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixPQUFyQixDQUFkOztBQUVQLElBQUlDLE1BQU0sQ0FBQ0MsUUFBWCxFQUFxQjtBQUNqQkQsUUFBTSxDQUFDRSxPQUFQLENBQWUsT0FBZixFQUF3QixTQUFTQyxnQkFBVCxHQUE0QjtBQUNoRCxXQUFPUCxLQUFLLENBQUNRLElBQU4sQ0FBVyxFQUFYLENBQVA7QUFDSCxHQUZEO0FBR0g7O0FBRURSLEtBQUssQ0FBQ1MsT0FBTixDQUFjO0FBQ1ZDLFdBQVMsR0FBRztBQUNSLFdBQU9SLFVBQVUsQ0FBQ1MsT0FBWCxDQUFtQjtBQUFDQyxTQUFHLEVBQUUsS0FBS0M7QUFBWCxLQUFuQixDQUFQO0FBQ0g7O0FBSFMsQ0FBZDtBQU1BVCxNQUFNLENBQUNVLE9BQVAsQ0FBZTtBQUNYLHVCQUF5QjtBQUFBLFFBQVY7QUFBRUM7QUFBRixLQUFVO0FBQ3JCLFVBQU1DLFlBQVksR0FBR2hCLEtBQUssQ0FBQ1csT0FBTixDQUFjO0FBQy9CRSxpQkFBVyxFQUFFRSxJQUFJLENBQUNGLFdBRGE7QUFFL0JJLFlBQU0sRUFBRUYsSUFBSSxDQUFDRSxNQUZrQjtBQUcvQkMsZUFBUyxFQUFFLEtBSG9CO0FBSS9CQyxXQUFLLEVBQUU7QUFKd0IsS0FBZCxDQUFyQjs7QUFPQSxRQUFJSCxZQUFKLEVBQWtCO0FBQ2RoQixXQUFLLENBQUNvQixNQUFOLENBQWFKLFlBQWIsb0JBQ09BLFlBRFA7QUFFSUssY0FBTSxFQUFFTCxZQUFZLENBQUNLLE1BQWIsR0FBb0JOLElBQUksQ0FBQ007QUFGckM7QUFJSCxLQUxELE1BS087QUFDSHJCLFdBQUssQ0FBQ3NCLE1BQU4sbUJBQ09QLElBRFA7QUFFSUcsaUJBQVMsRUFBRSxLQUZmO0FBR0lDLGFBQUssRUFBRTtBQUhYO0FBS0g7QUFDSjs7QUFyQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2xCQXhCLE1BQU0sQ0FBQ0ksTUFBUCxDQUFjO0FBQUNHLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQTJDLElBQUlELEtBQUo7QUFBVU4sTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSyxPQUFLLENBQUNILENBQUQsRUFBRztBQUFDRyxTQUFLLEdBQUNILENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsS0FBSjtBQUFVTCxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUNJLE9BQUssQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFNBQUssR0FBQ0YsQ0FBTjtBQUFROztBQUFsQixDQUF0QixFQUEwQyxDQUExQztBQUE2QyxJQUFJeUIsUUFBSjtBQUFhNUIsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDMkIsVUFBUSxDQUFDekIsQ0FBRCxFQUFHO0FBQUN5QixZQUFRLEdBQUN6QixDQUFUO0FBQVc7O0FBQXhCLENBQXpCLEVBQW1ELENBQW5EO0FBSXBLLE1BQU1JLFVBQVUsR0FBRyxJQUFJRCxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkI7O0FBRVAsSUFBSUMsTUFBTSxDQUFDQyxRQUFYLEVBQXFCO0FBQ2pCRCxRQUFNLENBQUNFLE9BQVAsQ0FBZSxZQUFmLEVBQTZCLFNBQVNrQixxQkFBVCxHQUFpQztBQUMxRCxXQUFPdEIsVUFBVSxDQUFDTSxJQUFYLENBQWdCLEVBQWhCLENBQVA7QUFDSCxHQUZEO0FBR0g7O0FBRUROLFVBQVUsQ0FBQ08sT0FBWCxDQUFtQjtBQUNmZ0IsU0FBTyxHQUFHO0FBQ04sV0FBT0YsUUFBUSxDQUFDWixPQUFULENBQWlCO0FBQUNDLFNBQUcsRUFBRSxLQUFLYztBQUFYLEtBQWpCLENBQVA7QUFDSCxHQUhjOztBQUlmQyxZQUFVLEdBQUc7QUFDVCxRQUFJQyxHQUFHLEdBQUcsQ0FBVjtBQUNBNUIsU0FBSyxDQUFDUSxJQUFOLENBQVc7QUFBQ0ssaUJBQVcsRUFBRSxLQUFLRCxHQUFuQjtBQUF3Qk0sZUFBUyxFQUFFO0FBQW5DLEtBQVgsRUFBc0RXLEtBQXRELEdBQThEQyxPQUE5RCxDQUFzRWYsSUFBSSxJQUFJO0FBQzFFYSxTQUFHLElBQUVHLFVBQVUsQ0FBQ2hCLElBQUksQ0FBQ00sTUFBTixDQUFmO0FBQ0gsS0FGRDtBQUdBLFdBQU9PLEdBQVA7QUFDSCxHQVZjOztBQVdmVixXQUFTLEdBQUc7QUFDUixRQUFJVSxHQUFHLEdBQUcsQ0FBVjtBQUNBNUIsU0FBSyxDQUFDUSxJQUFOLENBQVc7QUFBQ0ssaUJBQVcsRUFBRSxLQUFLRCxHQUFuQjtBQUF3Qk0sZUFBUyxFQUFFLElBQW5DO0FBQXlDQyxXQUFLLEVBQUU7QUFBaEQsS0FBWCxFQUFtRVUsS0FBbkUsR0FBMkVDLE9BQTNFLENBQW1GZixJQUFJLElBQUk7QUFDdkZhLFNBQUcsSUFBRUcsVUFBVSxDQUFDaEIsSUFBSSxDQUFDTSxNQUFOLENBQWY7QUFDSCxLQUZEO0FBR0EsV0FBT08sR0FBUDtBQUNIOztBQWpCYyxDQUFuQjtBQW9CQXhCLE1BQU0sQ0FBQ1UsT0FBUCxDQUFlO0FBQ1gsOEJBQThDO0FBQUEsUUFBeEI7QUFBQ0osZUFBRDtBQUFZUTtBQUFaLEtBQXdCO0FBQzFDbEIsU0FBSyxDQUFDUSxJQUFOLENBQVc7QUFDUEssaUJBQVcsRUFBRUgsU0FBUyxDQUFDRSxHQURoQjtBQUVQTSxlQUFTLEVBQUUsQ0FBQ0EsU0FGTDtBQUdQQyxXQUFLLEVBQUU7QUFIQSxLQUFYLEVBSUdVLEtBSkgsR0FJV0MsT0FKWCxDQUltQmYsSUFBSSxJQUFJO0FBQ3ZCLFlBQU1pQixRQUFRLEdBQUdoQyxLQUFLLENBQUNXLE9BQU4sQ0FBYztBQUMzQk0sY0FBTSxFQUFFRixJQUFJLENBQUNFLE1BRGM7QUFFM0JKLG1CQUFXLEVBQUVFLElBQUksQ0FBQ0YsV0FGUztBQUczQkssaUJBQVMsRUFBRUEsU0FIZ0I7QUFJM0JDLGFBQUssRUFBRTtBQUpvQixPQUFkLENBQWpCO0FBTUEsVUFBSWMsU0FBUyxHQUFHbEIsSUFBSSxDQUFDTSxNQUFyQjs7QUFDQSxVQUFJVyxRQUFKLEVBQWM7QUFDVkMsaUJBQVMsSUFBRUQsUUFBUSxDQUFDWCxNQUFwQjtBQUNBckIsYUFBSyxDQUFDa0MsTUFBTixDQUFhbkIsSUFBYjtBQUNBQSxZQUFJLEdBQUNpQixRQUFMO0FBQ0g7O0FBQ0RoQyxXQUFLLENBQUNvQixNQUFOLENBQWFMLElBQWIsRUFBbUI7QUFDZm9CLFlBQUksRUFBRTtBQUNGZCxnQkFBTSxFQUFFWSxTQUROO0FBRUZmLG1CQUFTLEVBQUVBO0FBRlQ7QUFEUyxPQUFuQjtBQU1ILEtBdkJEO0FBd0JILEdBMUJVOztBQTJCWCwrQkFBbUM7QUFBQSxRQUFiO0FBQUNSO0FBQUQsS0FBYTtBQUMvQlYsU0FBSyxDQUFDb0IsTUFBTixDQUFhO0FBQ1RQLGlCQUFXLEVBQUVILFNBQVMsQ0FBQ0UsR0FEZDtBQUVUTSxlQUFTLEVBQUU7QUFGRixLQUFiLEVBR0c7QUFDQ2lCLFVBQUksRUFBRTtBQUNGaEIsYUFBSyxFQUFFO0FBREw7QUFEUCxLQUhILEVBT0c7QUFDQ2lCLFdBQUssRUFBRTtBQURSLEtBUEg7QUFVSDs7QUF0Q1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ2hDQXpDLE1BQU0sQ0FBQ0ksTUFBUCxDQUFjO0FBQUN3QixVQUFRLEVBQUMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUl0QixLQUFKO0FBQVVOLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0ssT0FBSyxDQUFDSCxDQUFELEVBQUc7QUFBQ0csU0FBSyxHQUFDSCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlJLFVBQUo7QUFBZVAsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTSxZQUFVLENBQUNKLENBQUQsRUFBRztBQUFDSSxjQUFVLEdBQUNKLENBQVg7QUFBYTs7QUFBNUIsQ0FBM0IsRUFBeUQsQ0FBekQ7QUFHM0csTUFBTXlCLFFBQVEsR0FBRyxJQUFJdEIsS0FBSyxDQUFDRSxVQUFWLENBQXFCLFVBQXJCLENBQWpCOztBQUVQLElBQUlDLE1BQU0sQ0FBQ0MsUUFBWCxFQUFxQjtBQUNqQkQsUUFBTSxDQUFDRSxPQUFQLENBQWUsVUFBZixFQUEyQixTQUFTK0IsbUJBQVQsR0FBK0I7QUFDdEQsV0FBT2QsUUFBUSxDQUFDZixJQUFULENBQWMsRUFBZCxDQUFQO0FBQ0gsR0FGRDtBQUdIOztBQUVEZSxRQUFRLENBQUNkLE9BQVQsQ0FBaUI7QUFDYjZCLFlBQVUsR0FBRztBQUNULFdBQU9wQyxVQUFVLENBQUNNLElBQVgsQ0FBZ0I7QUFBQ2tCLGVBQVMsRUFBRSxLQUFLZDtBQUFqQixLQUFoQixFQUF1Q2lCLEtBQXZDLEVBQVA7QUFDSDs7QUFIWSxDQUFqQixFOzs7Ozs7Ozs7OztBQ1hBbEMsTUFBTSxDQUFDSSxNQUFQLENBQWM7QUFBQ3dDLE9BQUssRUFBQyxNQUFJQTtBQUFYLENBQWQ7QUFBaUMsSUFBSXRDLEtBQUo7QUFBVU4sTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSyxPQUFLLENBQUNILENBQUQsRUFBRztBQUFDRyxTQUFLLEdBQUNILENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsS0FBSjtBQUFVTCxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUNJLE9BQUssQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFNBQUssR0FBQ0YsQ0FBTjtBQUFROztBQUFsQixDQUF0QixFQUEwQyxDQUExQztBQUdoRyxNQUFNeUMsS0FBSyxHQUFHLElBQUl0QyxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDs7QUFFUCxJQUFJQyxNQUFNLENBQUNDLFFBQVgsRUFBcUI7QUFDakJELFFBQU0sQ0FBQ0UsT0FBUCxDQUFlLE9BQWYsRUFBd0IsU0FBU2tDLGdCQUFULEdBQTRCO0FBQ2hELFdBQU9ELEtBQUssQ0FBQy9CLElBQU4sQ0FBVyxFQUFYLENBQVA7QUFDSCxHQUZEO0FBR0g7O0FBRUQrQixLQUFLLENBQUM5QixPQUFOLENBQWM7QUFDVlMsV0FBUyxHQUFHO0FBQ1IsV0FBT2xCLEtBQUssQ0FBQ1EsSUFBTixDQUFXO0FBQUNTLFlBQU0sRUFBRSxLQUFLTCxHQUFkO0FBQW1CTSxlQUFTLEVBQUUsSUFBOUI7QUFBb0NDLFdBQUssRUFBRTtBQUEzQyxLQUFYLEVBQThEVSxLQUE5RCxFQUFQO0FBQ0g7O0FBSFMsQ0FBZCxFOzs7Ozs7Ozs7OztBQ1hBLElBQUl6QixNQUFKO0FBQVdULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ1EsUUFBTSxDQUFDTixDQUFELEVBQUc7QUFBQ00sVUFBTSxHQUFDTixDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5QyxLQUFKO0FBQVU1QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDMkMsT0FBSyxDQUFDekMsQ0FBRCxFQUFHO0FBQUN5QyxTQUFLLEdBQUN6QyxDQUFOO0FBQVE7O0FBQWxCLENBQW5DLEVBQXVELENBQXZEO0FBQTBELElBQUlFLEtBQUo7QUFBVUwsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ0ksT0FBSyxDQUFDRixDQUFELEVBQUc7QUFBQ0UsU0FBSyxHQUFDRixDQUFOO0FBQVE7O0FBQWxCLENBQW5DLEVBQXVELENBQXZEO0FBQTBELElBQUl5QixRQUFKO0FBQWE1QixNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWixFQUFzQztBQUFDMkIsVUFBUSxDQUFDekIsQ0FBRCxFQUFHO0FBQUN5QixZQUFRLEdBQUN6QixDQUFUO0FBQVc7O0FBQXhCLENBQXRDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlJLFVBQUo7QUFBZVAsTUFBTSxDQUFDQyxJQUFQLENBQVksMkJBQVosRUFBd0M7QUFBQ00sWUFBVSxDQUFDSixDQUFELEVBQUc7QUFBQ0ksY0FBVSxHQUFDSixDQUFYO0FBQWE7O0FBQTVCLENBQXhDLEVBQXNFLENBQXRFO0FBTXZTTSxNQUFNLENBQUNxQyxPQUFQLENBQWUsTUFBTSxDQUNwQixDQURELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuXHJcbmltcG9ydCB7UGFja2FnaW5nc30gZnJvbSBcIi4vcGFja2FnaW5nc1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEl0ZW1zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2l0ZW1zJyk7XHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcbiAgICBNZXRlb3IucHVibGlzaCgnaXRlbXMnLCBmdW5jdGlvbiBpdGVtc1B1YmxpY2F0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiBJdGVtcy5maW5kKHt9KTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5JdGVtcy5oZWxwZXJzKHtcclxuICAgIHBhY2thZ2luZygpIHtcclxuICAgICAgICByZXR1cm4gUGFja2FnaW5ncy5maW5kT25lKHtfaWQ6IHRoaXMucGFja2FnaW5nSWR9KTtcclxuICAgIH1cclxufSk7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcbiAgICAnaXRlbXMuaW5zZXJ0Jyh7IGl0ZW0gfSkge1xyXG4gICAgICAgIGNvbnN0IGV4aXN0aW5nSXRlbSA9IEl0ZW1zLmZpbmRPbmUoe1xyXG4gICAgICAgICAgICBwYWNrYWdpbmdJZDogaXRlbS5wYWNrYWdpbmdJZCxcclxuICAgICAgICAgICAgdXNlcklkOiBpdGVtLnVzZXJJZCxcclxuICAgICAgICAgICAgcmV0cmlldmVkOiBmYWxzZSxcclxuICAgICAgICAgICAgcGF5ZWQ6IGZhbHNlLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAoZXhpc3RpbmdJdGVtKSB7XHJcbiAgICAgICAgICAgIEl0ZW1zLnVwZGF0ZShleGlzdGluZ0l0ZW0sIHtcclxuICAgICAgICAgICAgICAgIC4uLmV4aXN0aW5nSXRlbSxcclxuICAgICAgICAgICAgICAgIGFtb3VudDogZXhpc3RpbmdJdGVtLmFtb3VudCtpdGVtLmFtb3VudCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgSXRlbXMuaW5zZXJ0KHtcclxuICAgICAgICAgICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgICAgICAgICByZXRyaWV2ZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgcGF5ZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pOyIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IHtJdGVtc30gZnJvbSBcIi4vaXRlbXNcIjtcclxuaW1wb3J0IHtQcm9kdWN0c30gZnJvbSBcIi4vcHJvZHVjdHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBQYWNrYWdpbmdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3BhY2thZ2luZ3MnKTtcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuICAgIE1ldGVvci5wdWJsaXNoKCdwYWNrYWdpbmdzJywgZnVuY3Rpb24gcGFja2FnaW5nc1B1YmxpY2F0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiBQYWNrYWdpbmdzLmZpbmQoe30pO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcblBhY2thZ2luZ3MuaGVscGVycyh7XHJcbiAgICBwcm9kdWN0KCkge1xyXG4gICAgICAgIHJldHVybiBQcm9kdWN0cy5maW5kT25lKHtfaWQ6IHRoaXMucHJvZHVjdElkfSk7XHJcbiAgICB9LFxyXG4gICAgdG9SZXRyaWV2ZSgpIHtcclxuICAgICAgICBsZXQgc3VtID0gMDtcclxuICAgICAgICBJdGVtcy5maW5kKHtwYWNrYWdpbmdJZDogdGhpcy5faWQsIHJldHJpZXZlZDogZmFsc2V9KS5mZXRjaCgpLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgICAgIHN1bSs9cGFyc2VGbG9hdChpdGVtLmFtb3VudCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHN1bTtcclxuICAgIH0sXHJcbiAgICByZXRyaWV2ZWQoKSB7XHJcbiAgICAgICAgbGV0IHN1bSA9IDA7XHJcbiAgICAgICAgSXRlbXMuZmluZCh7cGFja2FnaW5nSWQ6IHRoaXMuX2lkLCByZXRyaWV2ZWQ6IHRydWUsIHBheWVkOiBmYWxzZX0pLmZldGNoKCkuZm9yRWFjaChpdGVtID0+IHtcclxuICAgICAgICAgICAgc3VtKz1wYXJzZUZsb2F0KGl0ZW0uYW1vdW50KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gc3VtO1xyXG4gICAgfVxyXG59KTtcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdwYWNrYWdpbmdzLnJldHJpZXZlJyh7cGFja2FnaW5nLCByZXRyaWV2ZWR9KSB7XHJcbiAgICAgICAgSXRlbXMuZmluZCh7XHJcbiAgICAgICAgICAgIHBhY2thZ2luZ0lkOiBwYWNrYWdpbmcuX2lkLFxyXG4gICAgICAgICAgICByZXRyaWV2ZWQ6ICFyZXRyaWV2ZWQsXHJcbiAgICAgICAgICAgIHBheWVkOiBmYWxzZSxcclxuICAgICAgICB9KS5mZXRjaCgpLmZvckVhY2goaXRlbSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nID0gSXRlbXMuZmluZE9uZSh7XHJcbiAgICAgICAgICAgICAgICB1c2VySWQ6IGl0ZW0udXNlcklkLFxyXG4gICAgICAgICAgICAgICAgcGFja2FnaW5nSWQ6IGl0ZW0ucGFja2FnaW5nSWQsXHJcbiAgICAgICAgICAgICAgICByZXRyaWV2ZWQ6IHJldHJpZXZlZCxcclxuICAgICAgICAgICAgICAgIHBheWVkOiBmYWxzZSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGxldCBuZXdBbW91bnQgPSBpdGVtLmFtb3VudDtcclxuICAgICAgICAgICAgaWYgKGV4aXN0aW5nKSB7XHJcbiAgICAgICAgICAgICAgICBuZXdBbW91bnQrPWV4aXN0aW5nLmFtb3VudDtcclxuICAgICAgICAgICAgICAgIEl0ZW1zLnJlbW92ZShpdGVtKTtcclxuICAgICAgICAgICAgICAgIGl0ZW09ZXhpc3Rpbmc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgSXRlbXMudXBkYXRlKGl0ZW0sIHtcclxuICAgICAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IG5ld0Ftb3VudCxcclxuICAgICAgICAgICAgICAgICAgICByZXRyaWV2ZWQ6IHJldHJpZXZlZCxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSxcclxuICAgICdwYWNrYWdpbmdzLnNldFBheWVkJyh7cGFja2FnaW5nfSkge1xyXG4gICAgICAgIEl0ZW1zLnVwZGF0ZSh7XHJcbiAgICAgICAgICAgIHBhY2thZ2luZ0lkOiBwYWNrYWdpbmcuX2lkLFxyXG4gICAgICAgICAgICByZXRyaWV2ZWQ6IHRydWUsXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICBwYXllZDogdHJ1ZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgIG11bHRpOiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfSxcclxufSk7IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge1BhY2thZ2luZ3N9IGZyb20gXCIuL3BhY2thZ2luZ3NcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBQcm9kdWN0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwcm9kdWN0cycpO1xyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG4gICAgTWV0ZW9yLnB1Ymxpc2goJ3Byb2R1Y3RzJywgZnVuY3Rpb24gcHJvZHVjdHNQdWJsaWNhdGlvbigpIHtcclxuICAgICAgICByZXR1cm4gUHJvZHVjdHMuZmluZCh7fSk7XHJcbiAgICB9KTtcclxufVxyXG5cclxuUHJvZHVjdHMuaGVscGVycyh7XHJcbiAgICBwYWNrYWdpbmdzKCkge1xyXG4gICAgICAgIHJldHVybiBQYWNrYWdpbmdzLmZpbmQoe3Byb2R1Y3RJZDogdGhpcy5faWR9KS5mZXRjaCgpO1xyXG4gICAgfSxcclxufSk7IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQge0l0ZW1zfSBmcm9tIFwiLi9pdGVtc1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFVzZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJzJyk7XHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcbiAgICBNZXRlb3IucHVibGlzaCgndXNlcnMnLCBmdW5jdGlvbiB1c2Vyc1B1YmxpY2F0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiBVc2Vycy5maW5kKHt9KTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5Vc2Vycy5oZWxwZXJzKHtcclxuICAgIHJldHJpZXZlZCgpIHtcclxuICAgICAgICByZXR1cm4gSXRlbXMuZmluZCh7dXNlcklkOiB0aGlzLl9pZCwgcmV0cmlldmVkOiB0cnVlLCBwYXllZDogZmFsc2V9KS5mZXRjaCgpO1xyXG4gICAgfSxcclxufSk7XHJcbiIsImltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7VXNlcnN9IGZyb20gJy4uL2ltcG9ydHMvYXBpL3VzZXJzJztcbmltcG9ydCB7SXRlbXN9IGZyb20gJy4uL2ltcG9ydHMvYXBpL2l0ZW1zJ1xuaW1wb3J0IHtQcm9kdWN0c30gZnJvbSAnLi4vaW1wb3J0cy9hcGkvcHJvZHVjdHMnO1xuaW1wb3J0IHtQYWNrYWdpbmdzfSBmcm9tIFwiLi4vaW1wb3J0cy9hcGkvcGFja2FnaW5nc1wiO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG59KTtcbiJdfQ==
